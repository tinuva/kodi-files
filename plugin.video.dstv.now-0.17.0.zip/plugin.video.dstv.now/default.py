import sys

from resources.lib.plugin import plugin

plugin.dispatch(sys.argv[2])

# from slyguy.gui import ok
# ok('This add-on is currently broken. This is a known issue so no need to report it. There is no ETA on a fix')

from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    pass
    
_ = Language()
from slyguy import plugin, inputstream
# from slyguy.language import _

# import js2py
import requests
from bs4 import BeautifulSoup

from .constants import VIDEO_STREAMS, URL_EMBED, HEADERS

@plugin.route('')
def home(**kwargs):
    folder = plugin.Folder()

    folder.add_item(
            label = "Bok TV",
            path = plugin.url_for(play_boktv),
            playable = True,
        )

    for index, video in enumerate(VIDEO_STREAMS):
        folder.add_item(
            label = video['name'],
            path = plugin.url_for(play_video, index=index),
            playable = True,
        )

    # folder.add_item(label=_.SETTINGS, path=plugin.url_for(plugin.ROUTE_SETTINGS))


    return folder

@plugin.route()
def play_video(index, **kwargs):
    video = VIDEO_STREAMS[int(index)]

    item = plugin.Item(
        path = parse_embed(video['stream-key'])
    )

    item.inputstream = inputstream.HLS(force=True, live=True)
    return item

@plugin.route()
def play_boktv(**kwargs):
    # path = "https://livestream2.bokradio.co.za/hls/Bok5c_hd720.m3u8"
    item = plugin.Item(
        path = "https://livestream2.bokradio.co.za/hls/Bok5c.m3u8"
    )

    item.inputstream = inputstream.HLS(force=True, live=True)
    return item

def parse_embed(channel):
    response = requests.get(URL_EMBED+channel, headers=HEADERS)
    # headers = response.headers
    #print(headers)
    # print(response.text)
    soup = BeautifulSoup(response.text, 'html.parser')
    #print(soup.body.script.string)
    jscript = soup.body.script.string
    # func_name = jscript.split("{")[-7].split(",")[-6].split(":")[-1].replace(" ", "")
    stream_url_func = jscript.split("\n\n")[1] # or jscript.split("\n\n")[-3]
    req_var = stream_url_func.split(".")[-4].split(" ")[-1]
    req_element = stream_url_func.split(".")[-2].split("\"")[-2]
    var_list = jscript.split("\n\n")[0].split(";")
    req_var_content = []
    for i in var_list:
        if len(i) > 0:
            if i.split("var")[1].split(" ")[1] == req_var:
                req_var_content = i.split("var")[1].split(" ")[3] #.replace("\"","").replace("[","").replace("]","").split(",")
    req_element_content = soup.find("span", {"id": req_element}).text
    stream_url_func = stream_url_func.replace(req_var,req_var_content)
    stream_url_func = stream_url_func.replace("document.getElementById(\"" + req_element + "\").innerHTML","\""+req_element_content+"\"")
    url = "".join(stream_url_func.split("[")[1].split("]")[0].replace("\"","").replace("[","").replace("]","").split(",")).replace('\/', '/')
    url = url + "".join(req_var_content.replace("\"","").replace("[","").replace("]","").split(",")) + req_element_content
    return url
    # js_url_func =  js2py.eval_js(stream_url_func)
    # stream_url = js_url_func()
    # return stream_url
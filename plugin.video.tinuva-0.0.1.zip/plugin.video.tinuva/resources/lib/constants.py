VIDEO_TESTS = [
    {
        'name': 'HLS',
        'type': 'std',
        'url': 'https://cdn.bitmovin.com/content/assets/art-of-motion-dash-hls-progressive/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8',
    },
]

VIDEO_STREAMS = [
    {
        'name': 'Sky Sports Main Event',
        'stream-key': 'watch-sky-sports-main-event',
    },
    {
        'name': 'Sky Sports Premier League',
        'stream-key': 'sky-sports-premier-league',
    },
    {
        'name': 'Sky Sports Football',
        'stream-key': 'sky-sports-football',
    },
    {
        'name': 'Sky Sports Cricket',
        'stream-key': 'sky-sports-cricket',
    },
    {
        'name': 'Sky Sports News',
        'stream-key': 'sky-sports-news',
    },
    {
        'name': 'Sky Sports Action',
        'stream-key': 'sky-sports-action',
    },
    {
        'name': 'Sky Sports F1',
        'stream-key': 'sky-sports-f1',
    },
    {
        'name': 'Sky Sports Arena',
        'stream-key': 'sky-sports-arena',
    },
    {
        'name': 'Sky Sports Golf',
        'stream-key': 'sky-sports-golf',
    },
    {
        'name': 'Sky Sports Mix',
        'stream-key': 'sky-sports-mix',
    },
    {
        'name': 'SuperSport Grandstand',
        'stream-key': 'super-sport-grandstand',
    },
    {
        'name': 'SuperSport Premier League',
        'stream-key': 'super-sport-premier-league',
    },
    {
        'name': 'SuperSport Football',
        'stream-key': 'super-sport-football',
    },
    {
        'name': 'SuperSport Cricket',
        'stream-key': 'super-sport-cricket',
    },
    {
        'name': 'SuperSport LaLiga',
        'stream-key': 'super-sport-laliga',
    },
    {
        'name': 'SuperSport Rugby',
        'stream-key': 'super-sport-rugby',
    },
    {
        'name': 'SuperSport Action',
        'stream-key': 'super-sport-action',
    },
]


URL_EMBED = "https://streamia.xyz/embed/"
URL_REFERRER = "https://sportshd.co"

HEADERS = {
    "Referer": "https://sportshd.co/",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
}